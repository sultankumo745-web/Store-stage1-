import test from "node:test";
import assert from "node:assert/strict";
import { normalizePhone } from "../src/lib/phone.ts";
import { buildWaLink, fillTemplate } from "../src/lib/wa.ts";
import { formatMoney, toMinor, fromMinor } from "../src/lib/money.ts";
import { quoteDelivery, ruleKey } from "../src/lib/delivery.ts";
import { readableOn, isHex } from "../src/lib/theme.ts";
import { checkoutStatus } from "../src/lib/store-status.ts";

test("phone normalisation", () => {
  assert.equal(normalizePhone("08012345678"), "2348012345678");
  assert.equal(normalizePhone("+234 801 234 5678"), "2348012345678");
  assert.equal(normalizePhone("2348012345678"), "2348012345678");
  assert.equal(normalizePhone("8012345678"), "2348012345678");
  assert.equal(normalizePhone("+14155552671"), "14155552671");
  for (const bad of ["", "0801234567", "12345", "08112345", "abc", "0601234567890"]) assert.equal(normalizePhone(bad), null, bad);
});
test("whatsapp links", () => {
  assert.equal(buildWaLink(null, "hi"), null);
  assert.equal(buildWaLink("2348012345678", "Hi there"), "https://wa.me/2348012345678?text=Hi%20there");
  assert.equal(fillTemplate("{product} {price} {url}", { product: "A", price: "B", url: "C" }), "A B C");
});
test("money is integer minor units", () => {
  assert.equal(toMinor("1,500.50"), 150050);
  assert.equal(toMinor("2500"), 250000);
  assert.equal(toMinor("0.1"), 10);
  for (const bad of ["", "-5", "1.234", "abc", "99999999999"]) assert.equal(toMinor(bad), null, bad);
  assert.equal(fromMinor(150050), "1500.50");
  assert.match(formatMoney(150050), /₦\s?1,500\.50/);
});
test("delivery quote precedence", () => {
  const rules = [
    { type: "FIXED" as const, state: null, city: null, feeKobo: 400000 },
    { type: "STATE" as const, state: "Lagos", city: null, feeKobo: 250000 },
    { type: "CITY" as const, state: "Lagos", city: "Ikeja", feeKobo: 150000 },
  ];
  const cfg = { enabled: true, freeThresholdKobo: 10000000 };
  assert.deepEqual(quoteDelivery(100, { state: "lagos", city: " ikeja " }, cfg, rules), { available: true, feeKobo: 150000, reason: "city" });
  assert.deepEqual(quoteDelivery(100, { state: "Lagos", city: "Yaba" }, cfg, rules), { available: true, feeKobo: 250000, reason: "state" });
  assert.deepEqual(quoteDelivery(100, { state: "Kano" }, cfg, rules), { available: true, feeKobo: 400000, reason: "fixed" });
  assert.deepEqual(quoteDelivery(10000000, { state: "Kano" }, cfg, rules), { available: true, feeKobo: 0, reason: "free" });
  assert.deepEqual(quoteDelivery(100, { state: "Kano" }, { ...cfg, enabled: false }, rules), { available: false, reason: "disabled" });
  assert.deepEqual(quoteDelivery(100, { state: "Kano" }, cfg, []), { available: false, reason: "no_rule" });
  assert.equal(ruleKey({ type: "CITY", state: "Lagos", city: "Ikeja" }), "CITY:lagos:ikeja");
});
test("theme helpers and store status", () => {
  assert.equal(readableOn("#ffffff"), "#111111");
  assert.equal(readableOn("#000000"), "#ffffff");
  assert.ok(isHex("#0b6b43")); assert.ok(!isHex("0b6b43")); assert.ok(!isHex("#12345"));
  assert.equal(checkoutStatus({ storeOpen: true, closedMessage: null }).allowed, true);
  assert.equal(checkoutStatus({ storeOpen: false, closedMessage: null }).allowed, false);
});

"use server";
import { revalidateTag } from "next/cache";
import { prisma } from "@/lib/db";
import { requireOwner } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { deliveryRuleSchema } from "@/lib/validation";
import { ruleKey } from "@/lib/delivery";
import { firstErrors, type FormState } from "@/lib/form";

export async function addRule(_prev: FormState, fd: FormData): Promise<FormState> {
  await requireOwner();
  const { currencyCode } = await getSettings();
  const raw = { type: String(fd.get("type") ?? ""), state: String(fd.get("state") ?? ""), city: String(fd.get("city") ?? ""), fee: String(fd.get("fee") ?? "") };
  const p = deliveryRuleSchema(currencyCode).safeParse(raw);
  if (!p.success) return { ok: false, message: "Please fix the highlighted fields.", errors: firstErrors(p.error.flatten().fieldErrors), values: raw };
  const { type, state, city, fee } = p.data;
  const rule = { type, state, city: type === "CITY" ? city : null, feeKobo: fee as number };
  const matchKey = ruleKey(rule);
  await prisma.deliveryRule.upsert({ where: { matchKey }, update: { feeKobo: rule.feeKobo }, create: { ...rule, matchKey } });
  revalidateTag("settings");
  return { ok: true, message: "Delivery price saved." };
}
export async function deleteRule(id: string): Promise<void> {
  await requireOwner();
  await prisma.deliveryRule.deleteMany({ where: { id, type: { not: "FIXED" } } });
  revalidateTag("settings");
}

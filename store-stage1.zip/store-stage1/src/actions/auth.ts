"use server";
import bcrypt from "bcryptjs";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { createSession, destroySession } from "@/lib/auth";

const DUMMY_HASH = bcrypt.hashSync("not-a-real-password", 12); // keeps timing similar when the email is unknown
export type LoginState = { error?: string };

export async function login(_prev: LoginState, fd: FormData): Promise<LoginState> {
  const email = String(fd.get("email") ?? "").trim().toLowerCase().slice(0, 200);
  const password = String(fd.get("password") ?? "").slice(0, 200);
  const admin = await prisma.adminUser.findUnique({ where: { email } });
  if (admin?.lockedUntil && admin.lockedUntil > new Date()) return { error: "Too many failed attempts. Please try again in 15 minutes." };
  const ok = await bcrypt.compare(password, admin?.passwordHash ?? DUMMY_HASH);
  if (!admin || !admin.isActive || !ok) {
    if (admin) {
      const fails = admin.failedLogins + 1;
      await prisma.adminUser.update({ where: { id: admin.id }, data: { failedLogins: fails >= 5 ? 0 : fails, lockedUntil: fails >= 5 ? new Date(Date.now() + 15 * 60_000) : null } });
    }
    return { error: "Incorrect email or password." };
  }
  await prisma.adminUser.update({ where: { id: admin.id }, data: { failedLogins: 0, lockedUntil: null, lastLoginAt: new Date() } });
  await createSession(admin.id);
  redirect("/admin");
}
export async function logout() { await destroySession(); redirect("/admin/login"); }

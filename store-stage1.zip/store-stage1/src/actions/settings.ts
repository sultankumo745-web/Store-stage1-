"use server";
import { revalidateTag } from "next/cache";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/db";
import { requireOwner } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { SECTIONS, type SectionKey } from "@/lib/sections";
import { schemaFor } from "@/lib/validation";
import { firstErrors, type FormState } from "@/lib/form";
import { uploadImage } from "@/lib/storage";

/** One validated save path for business, contact, social, seo, status, branding and delivery. */
export async function saveSection(section: string, _prev: FormState, fd: FormData): Promise<FormState> {
  await requireOwner();
  const def = SECTIONS[section as SectionKey];
  if (!def) return { ok: false, message: "Unknown settings section." };
  const settings = await getSettings();

  const raw: Record<string, string | boolean> = {};
  for (const f of def.fields) if (f.type !== "image") raw[f.name] = f.type === "checkbox" ? fd.get(f.name) === "on" : String(fd.get(f.name) ?? "");

  const parsed = schemaFor(section as SectionKey, settings.currencyCode).safeParse(raw);
  if (!parsed.success) return { ok: false, message: "Some fields need fixing. Nothing was saved.", errors: firstErrors(parsed.error.flatten().fieldErrors), values: raw };
  let data: Record<string, unknown> = { ...parsed.data };

  for (const f of def.fields.filter((x) => x.type === "image")) {
    const file = fd.get(`file_${f.name}`);
    if (file instanceof File && file.size > 0) {
      const r = await uploadImage(file, f.name);
      if (!r.ok) return { ok: false, message: "Nothing was saved.", errors: { [f.name]: r.error }, values: raw };
      data[f.name] = r.url;
    } else if (fd.get(`remove_${f.name}`) === "on") data[f.name] = null;
  }

  if (section === "delivery") {
    const { fixedFee, freeDeliveryThreshold, ...rest } = data;
    data = { ...rest, freeDeliveryThresholdKobo: freeDeliveryThreshold as number | null };
    if (fixedFee === null) await prisma.deliveryRule.deleteMany({ where: { type: "FIXED" } });
    else await prisma.deliveryRule.upsert({ where: { matchKey: "FIXED" }, update: { feeKobo: fixedFee as number }, create: { type: "FIXED", matchKey: "FIXED", feeKobo: fixedFee as number } });
  }

  await prisma.storeSettings.update({ where: { id: 1 }, data: data as Prisma.StoreSettingsUpdateInput });
  revalidateTag("settings");
  return { ok: true, message: "Saved. Your store has been updated." };
}

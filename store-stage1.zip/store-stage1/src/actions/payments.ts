"use server";
import { revalidateTag } from "next/cache";
import { prisma } from "@/lib/db";
import { requireOwner } from "@/lib/auth";
import { PROVIDERS } from "@/lib/payment-meta";
import { gatewayConfigured } from "@/lib/payments";
import { paymentSchema } from "@/lib/validation";
import { firstErrors, type FormState } from "@/lib/form";

const s = (fd: FormData, k: string) => String(fd.get(k) ?? "");

export async function savePaymentMethod(provider: string, _prev: FormState, fd: FormData): Promise<FormState> {
  await requireOwner();
  const meta = PROVIDERS.find((p) => p.provider === provider);
  if (!meta) return { ok: false, message: "Unknown payment method." };
  const raw = { enabled: fd.get("enabled") === "on", instructions: s(fd, "instructions"), bankName: s(fd, "bankName"), accountName: s(fd, "accountName"), accountNumber: s(fd, "accountNumber"), walletProvider: s(fd, "walletProvider"), walletName: s(fd, "walletName"), walletNumber: s(fd, "walletNumber") };
  const parsed = paymentSchema.safeParse(raw);
  if (!parsed.success) return { ok: false, message: "Some fields need fixing. Nothing was saved.", errors: firstErrors(parsed.error.flatten().fieldErrors), values: raw };
  const d = parsed.data;

  if (d.enabled) {
    if (meta.kind === "gateway" && !gatewayConfigured(meta.provider))
      return { ok: false, values: raw, message: `${meta.label} can't be switched on yet. Add ${meta.envVars.join(", ")} to your hosting environment variables and redeploy first.` };
    if (meta.provider === "MANUAL_BANK") {
      const errors: Record<string, string> = {};
      if (!d.bankName) errors.bankName = "Required to enable bank transfer.";
      if (!d.accountName) errors.accountName = "Required to enable bank transfer.";
      if (!d.accountNumber) errors.accountNumber = "Required to enable bank transfer.";
      if (Object.keys(errors).length) return { ok: false, message: "Add your bank details before enabling.", errors, values: raw };
    }
    if (meta.provider === "MANUAL_WALLET") {
      const errors: Record<string, string> = {};
      if (!d.walletProvider) errors.walletProvider = "Required to enable wallet payment.";
      if (!d.walletNumber) errors.walletNumber = "Required to enable wallet payment.";
      if (Object.keys(errors).length) return { ok: false, message: "Add your wallet details before enabling.", errors, values: raw };
    }
  }
  const fields = meta.provider === "MANUAL_BANK" ? { bankName: d.bankName, accountName: d.accountName, accountNumber: d.accountNumber }
    : meta.provider === "MANUAL_WALLET" ? { walletProvider: d.walletProvider, walletName: d.walletName, walletNumber: d.walletNumber } : {};
  const common = { enabled: d.enabled, instructions: d.instructions, ...fields };
  await prisma.paymentMethod.upsert({ where: { provider: meta.provider }, update: common, create: { provider: meta.provider, label: meta.label, sortOrder: meta.sort, ...common } });
  revalidateTag("settings");
  return { ok: true, message: "Saved." };
}

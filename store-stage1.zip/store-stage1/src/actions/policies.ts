"use server";
import { revalidateTag } from "next/cache";
import { prisma } from "@/lib/db";
import { requireOwner } from "@/lib/auth";
import { policySchema } from "@/lib/validation";
import { firstErrors, type FormState } from "@/lib/form";

const KINDS = ["RETURNS", "REFUNDS", "PRIVACY", "TERMS", "DELIVERY"] as const;
export async function savePolicy(kind: string, _prev: FormState, fd: FormData): Promise<FormState> {
  await requireOwner();
  if (!KINDS.includes(kind as (typeof KINDS)[number])) return { ok: false, message: "Unknown policy." };
  const raw = { title: String(fd.get("title") ?? ""), content: String(fd.get("content") ?? ""), published: fd.get("published") === "on" };
  const p = policySchema.safeParse(raw);
  if (!p.success) return { ok: false, message: "Please fix the highlighted fields.", errors: firstErrors(p.error.flatten().fieldErrors), values: raw };
  const k = kind as (typeof KINDS)[number];
  await prisma.policy.upsert({ where: { kind: k }, update: p.data, create: { kind: k, ...p.data } });
  revalidateTag("settings");
  return { ok: true, message: "Saved." };
}

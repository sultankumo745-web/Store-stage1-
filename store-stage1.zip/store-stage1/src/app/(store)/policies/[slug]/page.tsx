import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getPolicies } from "@/lib/settings";

async function find(slug: string) { return (await getPolicies()).find((p) => p.kind.toLowerCase() === slug && p.published); }
export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const p = await find((await params).slug);
  return { title: p?.title ?? "Policy" };
}
export default async function PolicyPage({ params }: { params: Promise<{ slug: string }> }) {
  const p = await find((await params).slug);
  if (!p) notFound();
  // Rendered as plain text paragraphs only, never as HTML, so policy text cannot inject scripts.
  return <article className="prose"><h1>{p.title}</h1>{p.content.split(/\n{2,}/).map((para, i) => <p key={i}>{para}</p>)}</article>;
}

import Link from "next/link";
import type { ReactNode } from "react";
import { getSettings, getPolicies } from "@/lib/settings";
import { getAdmin } from "@/lib/auth";
import { buildWaLink } from "@/lib/wa";
import { displayPhone } from "@/lib/phone";
import { isDark } from "@/lib/theme";
import { SOCIALS } from "@/lib/social";
import { checkoutStatus } from "@/lib/store-status";

export default async function StoreLayout({ children }: { children: ReactNode }) {
  const s = await getSettings();
  const admin = s.maintenanceMode ? await getAdmin() : null;
  const wa = buildWaLink(s.whatsappNumber, s.whatsappGreeting);
  if (s.maintenanceMode && !admin) {
    return <main className="center"><h1>{s.businessName}</h1><p>{s.maintenanceMessage || "We are making improvements and will be back soon."}</p>{wa && <a className="btn wa" href={wa} target="_blank" rel="noopener">Chat with us on WhatsApp</a>}</main>;
  }
  const policies = (await getPolicies()).filter((p) => p.published);
  const socials = SOCIALS.map(([k, label]) => [s[k], label] as const).filter(([url]) => !!url);
  const logo = (isDark(s.secondaryColor) ? s.logoDarkUrl : s.logoUrl) || s.logoUrl;
  const status = checkoutStatus(s);
  return (
    <>
      {admin && <p className="banner info" style={{ borderRadius: 0, margin: 0 }}>Maintenance mode is ON. Customers cannot see the store. You can because you are signed in.</p>}
      <header className="site-head"><div className="wrap">
        <Link href="/" className="brand">{logo ? <img src={logo} alt={s.businessName} /> : s.businessName}</Link>
        {wa && <a className="btn wa sm" href={wa} target="_blank" rel="noopener">WhatsApp</a>}
      </div></header>
      {!status.allowed && <p className="banner bad" style={{ borderRadius: 0, margin: 0 }}>{status.message}</p>}
      <main className="wrap">{children}</main>
      <footer className="site-foot"><div className="wrap">
        <p><strong>{s.businessName}</strong>{s.tagline ? ` - ${s.tagline}` : ""}</p>
        {(s.phone || s.email || s.address || s.openingHours) && <p>
          {s.phone && <>Phone: <a href={`tel:+${s.phone}`}>{displayPhone(s.phone)}</a><br /></>}
          {s.email && <>Email: <a href={`mailto:${s.email}`}>{s.email}</a><br /></>}
          {s.address && <>{[s.address, s.lga, s.city, s.state].filter(Boolean).join(", ")}<br /></>}
          {s.openingHours && <>Hours: {s.openingHours}</>}</p>}
        {socials.length > 0 && <p>{socials.map(([url, label]) => <a key={label} href={url!} target="_blank" rel="noopener noreferrer">{label}</a>)}</p>}
        {policies.length > 0 && <p>{policies.map((p) => <Link key={p.kind} href={`/policies/${p.kind.toLowerCase()}`}>{p.title}</Link>)}</p>}
        <p>&copy; {new Date().getFullYear()} {s.businessName}</p>
      </div></footer>
    </>
  );
}

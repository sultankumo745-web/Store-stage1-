import { getSettings } from "@/lib/settings";
import { buildWaLink } from "@/lib/wa";

export default async function Home() {
  const s = await getSettings();
  const wa = buildWaLink(s.whatsappNumber, s.whatsappGreeting);
  return (
    <section className="hero">
      <h1>{s.businessName}</h1>
      {s.tagline && <p><strong>{s.tagline}</strong></p>}
      {s.description && <p>{s.description}</p>}
      <p>Products, cart and checkout arrive in the next build stage.</p>
      {wa && <a className="btn wa" href={wa} target="_blank" rel="noopener">Contact us on WhatsApp</a>}
    </section>
  );
}

import type { Metadata } from "next";
import type { CSSProperties, ReactNode } from "react";
import { getSettings } from "@/lib/settings";
import { themeVars } from "@/lib/theme";
import "./globals.css";

export const dynamic = "force-dynamic"; // settings come from the database (cached by tag), so nothing is baked in at build time

export async function generateMetadata(): Promise<Metadata> {
  const s = await getSettings();
  const title = s.defaultSeoTitle || (s.tagline ? `${s.businessName} - ${s.tagline}` : s.businessName);
  const description = s.defaultSeoDescription || s.description || undefined;
  return {
    metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
    title: { default: title, template: `%s | ${s.businessName}` }, description, applicationName: s.businessName,
    icons: s.faviconUrl ? { icon: s.faviconUrl } : undefined,
    openGraph: { type: "website", siteName: s.businessName, title, description, images: s.defaultOgImage ? [s.defaultOgImage] : undefined },
    twitter: { card: s.defaultOgImage ? "summary_large_image" : "summary", title, description },
    verification: s.siteVerification ? { google: s.siteVerification } : undefined,
  };
}
export default async function RootLayout({ children }: { children: ReactNode }) {
  const s = await getSettings();
  return <html lang="en" style={themeVars(s) as CSSProperties}><body>{children}</body></html>;
}

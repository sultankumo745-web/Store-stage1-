import Link from "next/link";
import { getSettings, getDeliveryRules } from "@/lib/settings";
import { getUsablePaymentMethods } from "@/lib/payments";
import { storageDriver } from "@/lib/storage";

export default async function Dashboard() {
  const s = await getSettings();
  const [rules, pay] = await Promise.all([getDeliveryRules(), getUsablePaymentMethods()]);
  const items: [boolean, string, string][] = [
    [s.businessName !== "Your Store", "Set your business name", "/admin/settings/business"],
    [!!s.whatsappNumber, "Add your WhatsApp number", "/admin/settings/contact"],
    [pay.length > 0, "Turn on at least one payment method", "/admin/settings/payments"],
    [s.deliveryEnabled && rules.length > 0, "Set up delivery pricing", "/admin/settings/delivery"],
    [!!storageDriver(), "Connect image storage (needed for logo uploads)", "/admin/settings/branding"],
  ];
  return (
    <>
      <h1>Dashboard</h1>
      <p className="help">Sales, orders and products will appear here in later stages. For now, finish setting up your store:</p>
      <section className="card"><h2>Setup checklist</h2>
        <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "grid", gap: 8 }}>
          {items.map(([done, label, href]) => <li key={label}><span className={done ? "badge ok" : "badge warn"}>{done ? "Done" : "To do"}</span> {done ? label : <Link href={href}>{label}</Link>}</li>)}
        </ul></section>
    </>
  );
}

import { requireOwner } from "@/lib/auth";
import { getSettings, getDeliveryRules } from "@/lib/settings";
import { SECTIONS } from "@/lib/sections";
import { fromMinor, formatMoney } from "@/lib/money";
import { SettingsForm } from "@/components/SettingsForm";
import { DeliveryRules } from "@/components/DeliveryRules";

export default async function DeliveryPage() {
  await requireOwner();
  const [s, rules] = await Promise.all([getSettings(), getDeliveryRules()]);
  const fixed = rules.find((r) => r.type === "FIXED");
  const values = {
    deliveryEnabled: s.deliveryEnabled, fixedFee: fixed ? fromMinor(fixed.feeKobo, s.currencyCode) : "",
    freeDeliveryThreshold: s.freeDeliveryThresholdKobo !== null ? fromMinor(s.freeDeliveryThresholdKobo, s.currencyCode) : "",
    deliveryInstructions: s.deliveryInstructions, deliveryEstimate: s.deliveryEstimate,
  };
  return (
    <>
      <h1>{SECTIONS.delivery.title}</h1><p className="help">{SECTIONS.delivery.intro}</p>
      <SettingsForm section="delivery" fields={SECTIONS.delivery.fields} values={values} />
      <DeliveryRules symbolHint={s.currencyCode} rules={rules.filter((r) => r.type !== "FIXED").map((r) => ({ id: r.id, type: r.type, state: r.state, city: r.city, price: formatMoney(r.feeKobo, s.currencyCode) }))} />
    </>
  );
}

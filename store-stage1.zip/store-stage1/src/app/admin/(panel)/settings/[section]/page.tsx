import { notFound } from "next/navigation";
import { requireOwner } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { SECTIONS, type SectionKey } from "@/lib/sections";
import { SettingsForm } from "@/components/SettingsForm";
import { STORAGE_HELP, storageDriver } from "@/lib/storage";

const SIMPLE: SectionKey[] = ["business", "contact", "social", "seo", "status"];
export default async function SectionPage({ params }: { params: Promise<{ section: string }> }) {
  await requireOwner();
  const { section } = await params;
  if (!SIMPLE.includes(section as SectionKey)) notFound();
  const def = SECTIONS[section as SectionKey];
  const s = await getSettings();
  const values = Object.fromEntries(def.fields.map((f) => [f.name, (s as Record<string, unknown>)[f.name] as string | boolean | null]));
  return (
    <>
      <h1>{def.title}</h1><p className="help">{def.intro}</p>
      {def.fields.some((f) => f.type === "image") && !storageDriver() && <p className="banner bad">{STORAGE_HELP}</p>}
      <SettingsForm section={section} fields={def.fields} values={values} />
    </>
  );
}

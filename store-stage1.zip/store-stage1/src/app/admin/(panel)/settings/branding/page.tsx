import { requireOwner } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { SECTIONS } from "@/lib/sections";
import { BrandingForm } from "@/components/BrandingForm";
import { STORAGE_HELP, storageDriver } from "@/lib/storage";

export default async function BrandingPage() {
  await requireOwner();
  const s = await getSettings();
  return (
    <>
      <h1>{SECTIONS.branding.title}</h1><p className="help">{SECTIONS.branding.intro} Changes apply to the whole store as soon as you save.</p>
      {!storageDriver() && <p className="banner bad">{STORAGE_HELP} Colours still work without it.</p>}
      <BrandingForm businessName={s.businessName} images={{ logoUrl: s.logoUrl, logoDarkUrl: s.logoDarkUrl, faviconUrl: s.faviconUrl }}
        theme={{ primaryColor: s.primaryColor, secondaryColor: s.secondaryColor, accentColor: s.accentColor, backgroundColor: s.backgroundColor, textColor: s.textColor, buttonColor: s.buttonColor }} />
    </>
  );
}

import { requireOwner } from "@/lib/auth";
import { getPaymentMethods } from "@/lib/settings";
import { gatewayConfigured } from "@/lib/payments";
import { PROVIDERS } from "@/lib/payment-meta";
import { PaymentCard } from "@/components/PaymentCard";

export default async function PaymentsPage() {
  await requireOwner();
  const rows = await getPaymentMethods();
  return (
    <>
      <h1>Payments</h1>
      <p className="help">Choose which payment methods customers can use. Secret keys are set in your hosting environment, never here. A method only appears at checkout when it is switched on and fully set up.</p>
      {PROVIDERS.map((p) => {
        const r = rows.find((x) => x.provider === p.provider);
        return <PaymentCard key={p.provider} provider={p.provider} label={p.label} kind={p.kind} envVars={p.envVars} configured={p.kind === "gateway" && gatewayConfigured(p.provider)}
          row={{ enabled: r?.enabled ?? false, instructions: r?.instructions ?? null, bankName: r?.bankName ?? null, accountName: r?.accountName ?? null, accountNumber: r?.accountNumber ?? null, walletProvider: r?.walletProvider ?? null, walletName: r?.walletName ?? null, walletNumber: r?.walletNumber ?? null }} />;
      })}
    </>
  );
}

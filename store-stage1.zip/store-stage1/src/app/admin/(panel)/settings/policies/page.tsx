import { requireOwner } from "@/lib/auth";
import { getPolicies } from "@/lib/settings";
import { PolicyCard } from "@/components/PolicyCard";

const KINDS = [["RETURNS", "Returns policy"], ["REFUNDS", "Refund policy"], ["PRIVACY", "Privacy policy"], ["TERMS", "Terms and conditions"], ["DELIVERY", "Delivery policy"]] as const;
export default async function PoliciesPage() {
  await requireOwner();
  const rows = await getPolicies();
  return (
    <>
      <h1>Policies</h1>
      <p className="help">These pages are shown in your store footer. The starter text is a placeholder: write your own, and consider having a lawyer review the privacy policy and terms.</p>
      {KINDS.map(([kind, label]) => {
        const p = rows.find((r) => r.kind === kind);
        return <PolicyCard key={kind} kind={kind} label={label} policy={{ title: p?.title ?? label, content: p?.content ?? "", published: p?.published ?? false }} />;
      })}
    </>
  );
}

import type { Metadata } from "next";
import type { ReactNode } from "react";
import { requireAdmin } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { logout } from "@/actions/auth";
import { AdminNav } from "@/components/AdminNav";

export const metadata: Metadata = { title: "Admin", robots: { index: false, follow: false } };
export default async function PanelLayout({ children }: { children: ReactNode }) {
  const admin = await requireAdmin();
  const s = await getSettings();
  return (
    <div className="admin">
      <aside className="side">
        <strong className="brand">{s.shortName}</strong><span className="muted">{admin.email}</span>
        <AdminNav />
        <form action={logout}><button className="btn ghost sm">Sign out</button></form>
      </aside>
      <div className="main">{children}</div>
    </div>
  );
}

import { redirect } from "next/navigation";
import type { Metadata } from "next";
import { getAdmin } from "@/lib/auth";
import { getSettings } from "@/lib/settings";
import { LoginForm } from "@/components/LoginForm";

export const metadata: Metadata = { title: "Admin sign in", robots: { index: false, follow: false } };
export default async function LoginPage() {
  if (await getAdmin()) redirect("/admin");
  const s = await getSettings();
  return (
    <div className="login card">
      {s.logoUrl ? <img src={s.logoUrl} alt={s.businessName} style={{ maxHeight: 48 }} /> : <h1>{s.businessName}</h1>}
      <h2>Admin sign in</h2>
      <LoginForm />
    </div>
  );
}

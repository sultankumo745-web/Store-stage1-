import "server-only";
import { cache } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { SignJWT, jwtVerify } from "jose";
import { prisma } from "./db";

export const SESSION_COOKIE = "admin_session";
const MAX_AGE = 60 * 60 * 24 * 7;
function key() {
  const s = process.env.AUTH_SECRET;
  if (!s || s.length < 32) throw new Error("AUTH_SECRET must be set to a random string of 32+ characters.");
  return new TextEncoder().encode(s);
}
export async function createSession(adminId: string) {
  const token = await new SignJWT({}).setProtectedHeader({ alg: "HS256" }).setSubject(adminId).setIssuedAt().setExpirationTime(`${MAX_AGE}s`).sign(key());
  (await cookies()).set(SESSION_COOKIE, token, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax", path: "/", maxAge: MAX_AGE });
}
export async function destroySession() { (await cookies()).delete(SESSION_COOKIE); }

/** Verifies the signed cookie AND re-checks the admin in the database, so deactivated admins lose access immediately. */
export const getAdmin = cache(async () => {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, key(), { algorithms: ["HS256"] });
    if (!payload.sub) return null;
    const a = await prisma.adminUser.findUnique({ where: { id: payload.sub }, select: { id: true, email: true, name: true, role: true, isActive: true } });
    return a && a.isActive ? a : null;
  } catch { return null; }
});
export async function requireAdmin() {
  const a = await getAdmin();
  if (!a) redirect("/admin/login");
  return a;
}
/** Settings, payments, delivery and policies are owner-only. */
export async function requireOwner() {
  const a = await requireAdmin();
  if (a.role !== "OWNER") redirect("/admin");
  return a;
}

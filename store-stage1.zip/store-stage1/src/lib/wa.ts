/** Pure WhatsApp helpers. Returns null when no number is configured so callers can hide the button. */
export function buildWaLink(number: string | null | undefined, text?: string | null): string | null {
  if (!number) return null;
  return `https://wa.me/${number}${text ? `?text=${encodeURIComponent(text)}` : ""}`;
}
export function fillTemplate(template: string, v: { product: string; price: string; url: string }): string {
  return template.split("{product}").join(v.product).split("{price}").join(v.price).split("{url}").join(v.url);
}

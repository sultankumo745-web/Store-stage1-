export function checkoutStatus(s: { storeOpen: boolean; closedMessage: string | null }): { allowed: boolean; message: string | null } {
  if (s.storeOpen) return { allowed: true, message: null };
  return { allowed: false, message: s.closedMessage || "The store is currently closed. You can browse products, but orders can't be placed right now." };
}

export type FormState = { ok: boolean; message?: string; errors?: Record<string, string>; values?: Record<string, string | boolean> };
export const initialState: FormState = { ok: false };
export function firstErrors(e: Record<string, string[] | undefined>): Record<string, string> {
  return Object.fromEntries(Object.entries(e).filter(([, v]) => v && v.length).map(([k, v]) => [k, v![0]]));
}

import "server-only";
import { unstable_cache } from "next/cache";
import { prisma } from "./db";
import type { StoreSettings } from "@prisma/client";

export type Settings = Omit<StoreSettings, "createdAt" | "updatedAt">;

/** THE settings loader. Every page, layout and action reads store data through here.
 *  Cached under the "settings" tag; saving anything calls revalidateTag("settings"). */
export const getSettings = unstable_cache(async (): Promise<Settings> => {
  const { createdAt, updatedAt, ...s } = await prisma.storeSettings.upsert({ where: { id: 1 }, update: {}, create: { id: 1 } });
  return s;
}, ["store-settings"], { tags: ["settings"] });

export const getDeliveryRules = unstable_cache(async () => {
  const rows = await prisma.deliveryRule.findMany({ orderBy: [{ type: "asc" }, { state: "asc" }, { city: "asc" }] });
  return rows.map(({ createdAt, updatedAt, ...r }) => r);
}, ["delivery-rules"], { tags: ["settings"] });

export const getPaymentMethods = unstable_cache(async () => {
  const rows = await prisma.paymentMethod.findMany({ orderBy: { sortOrder: "asc" } });
  return rows.map(({ createdAt, updatedAt, ...r }) => r);
}, ["payment-methods"], { tags: ["settings"] });

export const getPolicies = unstable_cache(async () => {
  const rows = await prisma.policy.findMany({ orderBy: { kind: "asc" } });
  return rows.map((p) => ({ id: p.id, kind: p.kind, title: p.title, content: p.content, published: p.published }));
}, ["policies"], { tags: ["settings"] });

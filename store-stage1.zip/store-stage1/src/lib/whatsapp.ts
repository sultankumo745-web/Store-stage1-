import "server-only";
import { getSettings } from "./settings";
import { buildWaLink, fillTemplate } from "./wa";
import { formatMoney } from "./money";

/** waLink(text): WhatsApp link for the configured number, or null (so callers hide the button). */
export async function waLink(text?: string): Promise<string | null> {
  const s = await getSettings();
  return buildWaLink(s.whatsappNumber, text ?? s.whatsappGreeting);
}
export async function productWaLink(p: { name: string; priceKobo: number; url: string }): Promise<string | null> {
  const s = await getSettings();
  return buildWaLink(s.whatsappNumber, fillTemplate(s.whatsappProductTemplate, { product: p.name, price: formatMoney(p.priceKobo, s.currencyCode), url: p.url }));
}

export const SOCIALS = [
  ["facebookUrl", "Facebook"], ["instagramUrl", "Instagram"], ["tiktokUrl", "TikTok"],
  ["twitterUrl", "X (Twitter)"], ["youtubeUrl", "YouTube"], ["telegramUrl", "Telegram"],
] as const;

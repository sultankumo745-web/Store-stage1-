export type Rule = { type: "FIXED" | "STATE" | "CITY"; state: string | null; city: string | null; feeKobo: number };
export type DeliveryConfig = { enabled: boolean; freeThresholdKobo: number | null };
export type Quote =
  | { available: true; feeKobo: number; reason: "free" | "city" | "state" | "fixed" }
  | { available: false; reason: "disabled" | "no_rule" };

const norm = (s?: string | null) => (s ?? "").trim().toLowerCase().replace(/\s+/g, " ");
export function ruleKey(r: { type: string; state?: string | null; city?: string | null }): string {
  if (r.type === "FIXED") return "FIXED";
  if (r.type === "STATE") return `STATE:${norm(r.state)}`;
  return `CITY:${norm(r.state)}:${norm(r.city)}`;
}

/** Single source of truth for delivery pricing. Checkout (Stage 2) must call this on the server. */
export function quoteDelivery(subtotalKobo: number, dest: { state: string; city?: string }, cfg: DeliveryConfig, rules: Rule[]): Quote {
  if (!cfg.enabled) return { available: false, reason: "disabled" };
  if (cfg.freeThresholdKobo !== null && subtotalKobo >= cfg.freeThresholdKobo) return { available: true, feeKobo: 0, reason: "free" };
  const by = new Map(rules.map((r) => [ruleKey(r), r]));
  const city = dest.city ? by.get(ruleKey({ type: "CITY", state: dest.state, city: dest.city })) : undefined;
  if (city) return { available: true, feeKobo: city.feeKobo, reason: "city" };
  const state = by.get(ruleKey({ type: "STATE", state: dest.state }));
  if (state) return { available: true, feeKobo: state.feeKobo, reason: "state" };
  const fixed = by.get("FIXED");
  if (fixed) return { available: true, feeKobo: fixed.feeKobo, reason: "fixed" };
  return { available: false, reason: "no_rule" };
}

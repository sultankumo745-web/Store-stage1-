/** Returns a digits-only international number (e.g. 2348012345678) or null when invalid. */
export function normalizePhone(input: string): string | null {
  const raw = input.trim();
  if (!raw) return null;
  let d = raw.replace(/\D/g, "");
  const intl = raw.startsWith("+") || d.startsWith("00");
  if (d.startsWith("00")) d = d.slice(2);
  const ngMobile = /^234[789]\d{9}$/;
  if (intl) {
    if (d.startsWith("234")) return ngMobile.test(d) ? d : null;
    return /^[1-9]\d{7,14}$/.test(d) ? d : null;
  }
  if (d.startsWith("234") && d.length === 13) return ngMobile.test(d) ? d : null;
  if (d.length === 11 && d.startsWith("0")) d = "234" + d.slice(1);
  else if (d.length === 10) d = "234" + d;
  return ngMobile.test(d) ? d : null;
}
export const displayPhone = (n: string) => "+" + n;

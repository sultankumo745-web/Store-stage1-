export type ProviderKey = "PAYSTACK" | "FLUTTERWAVE" | "MANUAL_BANK" | "MANUAL_WALLET";
export const PROVIDERS: { provider: ProviderKey; label: string; kind: "gateway" | "manual"; envVars: string[]; sort: number }[] = [
  { provider: "PAYSTACK", label: "Paystack", kind: "gateway", envVars: ["PAYSTACK_SECRET_KEY"], sort: 1 },
  { provider: "FLUTTERWAVE", label: "Flutterwave", kind: "gateway", envVars: ["FLUTTERWAVE_SECRET_KEY"], sort: 2 },
  { provider: "MANUAL_BANK", label: "Bank transfer (manual)", kind: "manual", envVars: [], sort: 3 },
  { provider: "MANUAL_WALLET", label: "Wallet / mobile money (manual)", kind: "manual", envVars: [], sort: 4 },
];

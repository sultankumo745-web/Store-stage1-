const fmt = (code: string, locale = "en") => new Intl.NumberFormat(locale, { style: "currency", currency: code });
export function isValidCurrency(code: string): boolean {
  if (!/^[A-Z]{3}$/.test(code)) return false;
  try { fmt(code); return true; } catch { return false; }
}
export function minorDigits(code: string): number {
  try { return fmt(code).resolvedOptions().maximumFractionDigits ?? 2; } catch { return 2; }
}
/** Amounts are stored as integer minor units (kobo for NGN). The symbol comes from the configured currency. */
export function formatMoney(minor: number, code = "NGN", locale = "en-NG"): string {
  return fmt(code, locale).format(minor / 10 ** minorDigits(code));
}
/** "1,500.50" -> 150050. Pure string maths, no floating point. Returns null if invalid or too large. */
export function toMinor(input: string, code = "NGN"): number | null {
  const d = minorDigits(code);
  const s = input.replace(/[,\s]/g, "");
  const ok = d === 0 ? /^\d+$/.test(s) : new RegExp(`^\\d+(\\.\\d{1,${d}})?$`).test(s);
  if (!ok) return null;
  const [whole, frac = ""] = s.split(".");
  const n = Number(whole + frac.padEnd(d, "0"));
  return Number.isSafeInteger(n) && n <= 2_147_483_647 ? n : null;
}
export function fromMinor(minor: number, code = "NGN"): string {
  const d = minorDigits(code);
  return (minor / 10 ** d).toFixed(d);
}

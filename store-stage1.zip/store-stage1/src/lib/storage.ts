import "server-only";
import { randomUUID } from "crypto";

const MAX_BYTES = 2 * 1024 * 1024;
const MIME = { png: "image/png", jpg: "image/jpeg", webp: "image/webp", ico: "image/x-icon" } as const;
type Kind = keyof typeof MIME;

/** Identify the real file type from its bytes. The browser-supplied type and filename are never trusted. */
function sniff(b: Uint8Array): Kind | null {
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return "png";
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return "jpg";
  if (b.length > 12 && String.fromCharCode(...b.slice(0, 4)) === "RIFF" && String.fromCharCode(...b.slice(8, 12)) === "WEBP") return "webp";
  if (b[0] === 0 && b[1] === 0 && b[2] === 1 && b[3] === 0) return "ico";
  return null;
}
const S3_KEYS = ["S3_BUCKET", "S3_REGION", "S3_ACCESS_KEY_ID", "S3_SECRET_ACCESS_KEY", "S3_PUBLIC_BASE_URL"];
export function storageDriver(): "vercel-blob" | "s3" | null {
  const d = process.env.STORAGE_DRIVER;
  if (d === "vercel-blob" && process.env.BLOB_READ_WRITE_TOKEN) return "vercel-blob";
  if (d === "s3" && S3_KEYS.every((k) => process.env[k])) return "s3";
  return null;
}
export const STORAGE_HELP = "Image uploads are not set up yet. Add the storage variables from .env.example (STORAGE_DRIVER and its keys) in your hosting settings, then redeploy.";

export async function uploadImage(file: File, field: string): Promise<{ ok: true; url: string } | { ok: false; error: string }> {
  const driver = storageDriver();
  if (!driver) return { ok: false, error: STORAGE_HELP };
  if (file.size > MAX_BYTES) return { ok: false, error: "That image is too large. The maximum size is 2 MB." };
  const bytes = new Uint8Array(await file.arrayBuffer());
  const kind = sniff(bytes);
  if (!kind) return { ok: false, error: "Use a PNG, JPG or WEBP image (ICO is allowed for the favicon)." };
  if (kind === "ico" && field !== "faviconUrl") return { ok: false, error: "ICO files can only be used for the favicon." };
  const key = `branding/${field}-${randomUUID()}.${kind}`;
  try {
    if (driver === "vercel-blob") {
      const { put } = await import("@vercel/blob");
      const r = await put(key, Buffer.from(bytes), { access: "public", contentType: MIME[kind], addRandomSuffix: false });
      return { ok: true, url: r.url };
    }
    const { S3Client, PutObjectCommand } = await import("@aws-sdk/client-s3");
    const c = new S3Client({
      region: process.env.S3_REGION!, endpoint: process.env.S3_ENDPOINT || undefined, forcePathStyle: !!process.env.S3_ENDPOINT,
      credentials: { accessKeyId: process.env.S3_ACCESS_KEY_ID!, secretAccessKey: process.env.S3_SECRET_ACCESS_KEY! },
    });
    await c.send(new PutObjectCommand({ Bucket: process.env.S3_BUCKET!, Key: key, Body: bytes, ContentType: MIME[kind], CacheControl: "public, max-age=31536000, immutable" }));
    return { ok: true, url: `${process.env.S3_PUBLIC_BASE_URL!.replace(/\/$/, "")}/${key}` };
  } catch {
    return { ok: false, error: "The image could not be uploaded. Check your storage settings and try again." };
  }
}

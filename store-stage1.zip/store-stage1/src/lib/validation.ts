import { z } from "zod";
import { normalizePhone } from "./phone";
import { isValidCurrency, toMinor } from "./money";
import { THEME_KEYS } from "./theme";
import { NG_STATES } from "./ng";
import type { SectionKey } from "./sections";

const t = (max: number, label: string) => z.string().trim().max(max, `${label} must be ${max} characters or fewer.`);
const req = (max: number, label: string) => t(max, label).min(1, `${label} is required.`);
const opt = (max: number, label: string) => t(max, label).transform((v) => (v === "" ? null : v));
const link = (label: string) => opt(300, label).refine((v) => { if (v === null) return true; try { return new URL(v).protocol === "https:"; } catch { return false; } }, `${label} must be a full link starting with https://`);
const hex = (label: string) => z.string().trim().regex(/^#[0-9a-fA-F]{6}$/, `${label} must be a HEX colour like #0b6b43.`).transform((v) => v.toLowerCase());
const email = (label: string) => opt(120, label).refine((v) => v === null || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), `${label} is not a valid email address.`);
const phone = (label: string) => opt(30, label).transform((v, ctx) => {
  if (v === null) return null;
  const n = normalizePhone(v);
  if (!n) { ctx.addIssue({ code: "custom", message: `${label} is not valid. Use a number like 08012345678.` }); return z.NEVER; }
  return n;
});
export const money = (label: string, code: string) => opt(14, label).transform((v, ctx) => {
  if (v === null) return null;
  const m = toMinor(v, code);
  if (m === null) { ctx.addIssue({ code: "custom", message: `${label} must be an amount like 2500 or 2500.50.` }); return z.NEVER; }
  return m;
});

type AnySchema = z.ZodType<Record<string, unknown>, z.ZodTypeDef, unknown>;
export function schemaFor(section: SectionKey, code: string): AnySchema {
  switch (section) {
    case "business": return z.object({
      businessName: req(80, "Business name"), shortName: req(30, "Short name"), tagline: opt(120, "Tagline"), description: opt(500, "Description"),
      currencyCode: z.string().trim().transform((v) => v.toUpperCase()).refine(isValidCurrency, "Enter a valid 3-letter currency code, for example NGN."),
    });
    case "contact": return z.object({
      phone: phone("Phone number"), whatsappNumber: phone("WhatsApp number"),
      whatsappGreeting: req(300, "Default WhatsApp message"), whatsappProductTemplate: req(400, "Product enquiry message"),
      email: email("Email"), address: opt(200, "Address"), state: opt(40, "State"), city: opt(60, "City"), lga: opt(60, "LGA"), openingHours: opt(150, "Opening hours"),
    });
    case "social": return z.object({
      facebookUrl: link("Facebook link"), instagramUrl: link("Instagram link"), tiktokUrl: link("TikTok link"),
      twitterUrl: link("X link"), youtubeUrl: link("YouTube link"), telegramUrl: link("Telegram link"),
    });
    case "seo": return z.object({
      defaultSeoTitle: opt(70, "Website title"), defaultSeoDescription: opt(160, "Website description"),
      siteVerification: opt(120, "Verification code").refine((v) => v === null || /^[\w-]{10,120}$/.test(v), "Paste only the verification code (letters, numbers, - and _)."),
    });
    case "status": return z.object({
      maintenanceMode: z.boolean(), maintenanceMessage: opt(300, "Maintenance message"), storeOpen: z.boolean(), closedMessage: opt(300, "Closed message"),
    });
    case "branding": return z.object(Object.fromEntries(THEME_KEYS.map((k) => [k, hex(k.replace("Color", " colour"))])) as Record<(typeof THEME_KEYS)[number], ReturnType<typeof hex>>);
    case "delivery": return z.object({
      deliveryEnabled: z.boolean(), fixedFee: money("Default delivery fee", code), freeDeliveryThreshold: money("Free delivery amount", code),
      deliveryInstructions: opt(500, "Delivery notes"), deliveryEstimate: opt(150, "Delivery estimate"),
    });
  }
}

export const paymentSchema = z.object({
  enabled: z.boolean(), instructions: opt(500, "Payment instructions"),
  bankName: opt(60, "Bank name"), accountName: opt(80, "Account name"),
  accountNumber: opt(10, "Account number").refine((v) => v === null || /^\d{10}$/.test(v), "Account number must be 10 digits."),
  walletProvider: opt(60, "Wallet provider"), walletName: opt(80, "Wallet name"), walletNumber: opt(30, "Wallet number"),
});

export const deliveryRuleSchema = (code: string) => z.object({
  type: z.enum(["STATE", "CITY"]),
  state: z.enum(NG_STATES, { errorMap: () => ({ message: "Choose a state." }) }),
  city: t(60, "City"),
  fee: money("Fee", code).refine((v) => v !== null, "Enter the delivery fee."),
}).superRefine((v, ctx) => { if (v.type === "CITY" && !v.city) ctx.addIssue({ code: "custom", path: ["city"], message: "Enter the city." }); });

export const policySchema = z.object({ title: req(100, "Title"), content: req(20000, "Policy text"), published: z.boolean() });

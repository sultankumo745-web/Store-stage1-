export type Theme = { primaryColor: string; secondaryColor: string; accentColor: string; backgroundColor: string; textColor: string; buttonColor: string };
export const THEME_KEYS = ["primaryColor", "secondaryColor", "accentColor", "backgroundColor", "textColor", "buttonColor"] as const;
export const DEFAULT_THEME: Theme = { primaryColor: "#0b6b43", secondaryColor: "#1f2a24", accentColor: "#f2b01e", backgroundColor: "#f5f6f4", textColor: "#16201b", buttonColor: "#0b6b43" };
export const PRESETS: Record<string, Theme> = {
  Default: DEFAULT_THEME,
  Modern: { primaryColor: "#2563eb", secondaryColor: "#0f172a", accentColor: "#f97316", backgroundColor: "#f8fafc", textColor: "#0f172a", buttonColor: "#2563eb" },
  Elegant: { primaryColor: "#5b3a29", secondaryColor: "#2b2118", accentColor: "#c9a227", backgroundColor: "#faf7f2", textColor: "#2b2118", buttonColor: "#5b3a29" },
  Bold: { primaryColor: "#d6001c", secondaryColor: "#111111", accentColor: "#ffd400", backgroundColor: "#ffffff", textColor: "#111111", buttonColor: "#d6001c" },
  Minimal: { primaryColor: "#111111", secondaryColor: "#444444", accentColor: "#888888", backgroundColor: "#ffffff", textColor: "#111111", buttonColor: "#111111" },
};
export const isHex = (v: string) => /^#[0-9a-fA-F]{6}$/.test(v);
function luminance(hex: string): number {
  const n = parseInt(hex.slice(1), 16);
  const [r, g, b] = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
/** Text colour that stays readable on the given background. */
export const readableOn = (hex: string) => (luminance(hex) < 0.179 ? "#ffffff" : "#111111");
export const isDark = (hex: string) => luminance(hex) < 0.179;
export function themeVars(t: Theme): Record<string, string> {
  return {
    "--primary": t.primaryColor, "--primary-ink": readableOn(t.primaryColor),
    "--secondary": t.secondaryColor, "--secondary-ink": readableOn(t.secondaryColor),
    "--accent": t.accentColor, "--accent-ink": readableOn(t.accentColor),
    "--bg": t.backgroundColor, "--text": t.textColor,
    "--button": t.buttonColor, "--button-ink": readableOn(t.buttonColor),
  };
}

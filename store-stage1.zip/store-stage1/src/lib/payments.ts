import "server-only";
import { PROVIDERS, type ProviderKey } from "./payment-meta";
import { getPaymentMethods } from "./settings";

/** "Configured" only means the secret exists in the environment. It is never read into the browser or the database. */
export const gatewayConfigured = (p: ProviderKey) => (PROVIDERS.find((x) => x.provider === p)?.envVars ?? []).every((v) => !!process.env[v]);

type Row = { provider: string; enabled: boolean; bankName: string | null; accountName: string | null; accountNumber: string | null; walletProvider: string | null; walletNumber: string | null };
export function isUsable(m: Row): boolean {
  if (!m.enabled) return false;
  switch (m.provider) {
    case "PAYSTACK": case "FLUTTERWAVE": return gatewayConfigured(m.provider);
    case "MANUAL_BANK": return !!(m.bankName && m.accountName && m.accountNumber);
    case "MANUAL_WALLET": return !!(m.walletProvider && m.walletNumber);
    default: return false;
  }
}
/** Stage 2 checkout must show only these. */
export async function getUsablePaymentMethods() { return (await getPaymentMethods()).filter(isUsable); }

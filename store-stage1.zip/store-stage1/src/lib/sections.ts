export type FieldType = "text" | "textarea" | "email" | "tel" | "url" | "checkbox" | "image" | "money";
export type Field = { name: string; label: string; type: FieldType; help?: string; placeholder?: string };
export type SectionKey = "business" | "contact" | "social" | "seo" | "status" | "branding" | "delivery";
export const SECTIONS: Record<SectionKey, { title: string; intro: string; fields: Field[] }> = {
  business: { title: "Business", intro: "Your store name and description. These update everywhere on the site.", fields: [
    { name: "businessName", label: "Business name", type: "text", help: "Shown in the header, footer, checkout, emails and search results." },
    { name: "shortName", label: "Short name", type: "text", help: "Used where space is tight, for example the admin menu." },
    { name: "tagline", label: "Tagline", type: "text" },
    { name: "description", label: "Business description", type: "textarea", help: "A short paragraph about what you sell." },
    { name: "currencyCode", label: "Currency code", type: "text", placeholder: "NGN", help: "3-letter code. NGN for Naira. The symbol is added automatically." },
  ] },
  contact: { title: "Contact", intro: "How customers reach you.", fields: [
    { name: "phone", label: "Phone number", type: "tel", placeholder: "08012345678" },
    { name: "whatsappNumber", label: "WhatsApp number", type: "tel", placeholder: "08012345678", help: "Nigerian numbers are converted automatically. Leave empty to hide all WhatsApp buttons." },
    { name: "whatsappGreeting", label: "Default WhatsApp message", type: "textarea" },
    { name: "whatsappProductTemplate", label: "Product enquiry message", type: "textarea", help: "Use {product}, {price} and {url}. They are filled in on each product page." },
    { name: "email", label: "Email", type: "email" },
    { name: "address", label: "Business address", type: "text" },
    { name: "state", label: "State", type: "text" },
    { name: "city", label: "City", type: "text" },
    { name: "lga", label: "Local Government Area", type: "text" },
    { name: "openingHours", label: "Opening hours", type: "text", placeholder: "Mon-Sat, 9am-6pm" },
  ] },
  social: { title: "Social media", intro: "Only links you fill in are shown on the site. Use the full https:// address of your page.", fields: [
    { name: "facebookUrl", label: "Facebook page", type: "url", placeholder: "https://facebook.com/yourpage" },
    { name: "instagramUrl", label: "Instagram", type: "url", placeholder: "https://instagram.com/yourhandle" },
    { name: "tiktokUrl", label: "TikTok", type: "url", placeholder: "https://tiktok.com/@yourhandle" },
    { name: "twitterUrl", label: "X (Twitter)", type: "url", placeholder: "https://x.com/yourhandle" },
    { name: "youtubeUrl", label: "YouTube", type: "url" },
    { name: "telegramUrl", label: "Telegram", type: "url", placeholder: "https://t.me/yourhandle" },
  ] },
  seo: { title: "SEO and sharing", intro: "How your store appears on Google and when its link is shared.", fields: [
    { name: "defaultSeoTitle", label: "Website title", type: "text", help: "Up to 70 characters. Leave empty to use your business name and tagline." },
    { name: "defaultSeoDescription", label: "Website description", type: "textarea", help: "Up to 160 characters." },
    { name: "defaultOgImage", label: "Default sharing image", type: "image", help: "Shown when a page without its own image is shared. 1200 x 630 works best." },
    { name: "siteVerification", label: "Google site verification code", type: "text", help: "Paste only the code, not the whole tag." },
  ] },
  status: { title: "Store status", intro: "Pause the store or stop orders temporarily.", fields: [
    { name: "maintenanceMode", label: "Maintenance mode (customers see a maintenance page; admins still get in)", type: "checkbox" },
    { name: "maintenanceMessage", label: "Maintenance message", type: "textarea" },
    { name: "storeOpen", label: "Store is open for orders", type: "checkbox", help: "Untick to let customers browse but not check out." },
    { name: "closedMessage", label: "Message when closed", type: "textarea" },
  ] },
  branding: { title: "Branding", intro: "Logo, favicon and colours.", fields: [
    { name: "logoUrl", label: "Logo", type: "image", help: "Used on light backgrounds." },
    { name: "logoDarkUrl", label: "Logo for dark backgrounds (optional)", type: "image" },
    { name: "faviconUrl", label: "Favicon", type: "image", help: "Small square icon shown in browser tabs. PNG or ICO." },
    { name: "primaryColor", label: "Primary colour", type: "text" }, { name: "secondaryColor", label: "Secondary colour", type: "text" },
    { name: "accentColor", label: "Accent colour", type: "text" }, { name: "backgroundColor", label: "Background colour", type: "text" },
    { name: "textColor", label: "Text colour", type: "text" }, { name: "buttonColor", label: "Button colour", type: "text" },
  ] },
  delivery: { title: "Delivery", intro: "Delivery pricing is calculated on the server. Set the basics here, then add state or city prices below.", fields: [
    { name: "deliveryEnabled", label: "Offer delivery", type: "checkbox" },
    { name: "fixedFee", label: "Default delivery fee", type: "money", help: "Used when no state or city price matches. Leave empty for no default." },
    { name: "freeDeliveryThreshold", label: "Free delivery above", type: "money", help: "Orders at or above this amount get free delivery. Leave empty for never." },
    { name: "deliveryInstructions", label: "Delivery notes for customers", type: "textarea" },
    { name: "deliveryEstimate", label: "Estimated delivery time", type: "text", placeholder: "2-5 working days" },
  ] },
};

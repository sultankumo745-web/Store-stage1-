import { NextResponse, type NextRequest } from "next/server";
import { jwtVerify } from "jose";

/** First gate for /admin/*. Pages and actions ALSO check the session on the server (defence in depth). */
export async function middleware(req: NextRequest) {
  if (req.nextUrl.pathname === "/admin/login") return NextResponse.next();
  const token = req.cookies.get("admin_session")?.value;
  const secret = process.env.AUTH_SECRET;
  try {
    if (!token || !secret) throw new Error("no session");
    await jwtVerify(token, new TextEncoder().encode(secret), { algorithms: ["HS256"] });
    return NextResponse.next();
  } catch {
    const url = req.nextUrl.clone();
    url.pathname = "/admin/login"; url.search = "";
    return NextResponse.redirect(url);
  }
}
export const config = { matcher: ["/admin/:path*"] };

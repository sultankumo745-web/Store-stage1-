"use client";
import { useState } from "react";
import type { Field } from "@/lib/sections";
import type { FormState } from "@/lib/form";

export type Val = string | boolean | null | undefined;

export function FormBanner({ state }: { state: FormState }) {
  if (!state.message) return null;
  return <p role="status" className={state.ok ? "banner ok" : "banner bad"}>{state.message}</p>;
}
export function Err({ id, error }: { id: string; error?: string }) {
  return error ? <p id={`${id}-err`} className="error">{error}</p> : null;
}
export function ImageField({ name, label, help, current, error }: { name: string; label: string; help?: string; current?: string | null; error?: string }) {
  const [preview, setPreview] = useState<string | null>(null);
  const [removed, setRemoved] = useState(false);
  const shown = preview ?? (removed ? null : current ?? null);
  return (
    <div className="field">
      <label htmlFor={`file_${name}`}>{label}</label>
      {help && <p className="help">{help}</p>}
      {shown && <img className="thumb" src={shown} alt={`${label} preview`} />}
      <input id={`file_${name}`} name={`file_${name}`} type="file" accept="image/png,image/jpeg,image/webp,.ico"
        onChange={(e) => { const f = e.target.files?.[0]; setPreview(f ? URL.createObjectURL(f) : null); if (f) setRemoved(false); }} />
      {current && <label className="check"><input type="checkbox" name={`remove_${name}`} checked={removed} onChange={(e) => setRemoved(e.target.checked)} /> Remove current image</label>}
      <Err id={name} error={error} />
    </div>
  );
}
export function FieldRow({ f, value, error }: { f: Field; value: Val; error?: string }) {
  const id = `f_${f.name}`;
  if (f.type === "image") return <ImageField name={f.name} label={f.label} help={f.help} current={typeof value === "string" ? value : null} error={error} />;
  if (f.type === "checkbox")
    return <div className="field"><label className="check"><input id={id} name={f.name} type="checkbox" defaultChecked={!!value} /> {f.label}</label>{f.help && <p className="help">{f.help}</p>}<Err id={id} error={error} /></div>;
  const common = { id, name: f.name, defaultValue: (value ?? "") as string, placeholder: f.placeholder, "aria-invalid": !!error, "aria-describedby": error ? `${id}-err` : undefined };
  return (
    <div className="field">
      <label htmlFor={id}>{f.label}</label>
      {f.help && <p className="help">{f.help}</p>}
      {f.type === "textarea" ? <textarea rows={3} {...common} /> : <input type={f.type === "money" ? "text" : f.type} inputMode={f.type === "money" ? "decimal" : undefined} {...common} />}
      <Err id={id} error={error} />
    </div>
  );
}

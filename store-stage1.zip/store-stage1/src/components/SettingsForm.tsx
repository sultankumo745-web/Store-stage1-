"use client";
import { useActionState } from "react";
import { saveSection } from "@/actions/settings";
import { initialState } from "@/lib/form";
import type { Field } from "@/lib/sections";
import { FieldRow, FormBanner, type Val } from "./fields";

export function SettingsForm({ section, fields, values }: { section: string; fields: Field[]; values: Record<string, Val> }) {
  const [state, action, pending] = useActionState(saveSection.bind(null, section), initialState);
  return (
    <form action={action} className="card form" noValidate>
      <FormBanner state={state} />
      {fields.map((f) => <FieldRow key={f.name} f={f} value={state.values?.[f.name] ?? values[f.name]} error={state.errors?.[f.name]} />)}
      <button className="btn" disabled={pending}>{pending ? "Saving…" : "Save changes"}</button>
    </form>
  );
}

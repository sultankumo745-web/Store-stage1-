"use client";
import { useActionState, useState } from "react";
import { addRule, deleteRule } from "@/actions/delivery";
import { initialState } from "@/lib/form";
import { NG_STATES } from "@/lib/ng";
import { FormBanner, Err } from "./fields";

type R = { id: string; type: string; state: string | null; city: string | null; price: string };

export function DeliveryRules({ rules, symbolHint }: { rules: R[]; symbolHint: string }) {
  const [state, action, pending] = useActionState(addRule, initialState);
  const [type, setType] = useState("STATE");
  return (
    <section className="card">
      <h2>Prices by state or city</h2>
      <p className="help">A city price beats a state price, and a state price beats the default fee. Prices are in {symbolHint}.</p>
      {rules.length === 0 ? <p className="empty">No state or city prices yet. The default fee (if set) applies everywhere.</p> : (
        <div className="scroll"><table><thead><tr><th>Place</th><th>Price</th><th></th></tr></thead><tbody>
          {rules.map((r) => (
            <tr key={r.id}><td>{r.type === "CITY" ? `${r.city}, ${r.state}` : r.state}</td><td>{r.price}</td>
              <td><form action={deleteRule.bind(null, r.id)} onSubmit={(e) => { if (!confirm("Remove this delivery price?")) e.preventDefault(); }}><button className="btn ghost sm">Remove</button></form></td></tr>
          ))}</tbody></table></div>)}
      <form action={action} className="form" noValidate>
        <h3>Add or update a price</h3>
        <FormBanner state={state} />
        <div className="field"><label htmlFor="r_type">Applies to</label>
          <select id="r_type" name="type" value={type} onChange={(e) => setType(e.target.value)}><option value="STATE">A whole state</option><option value="CITY">One city</option></select></div>
        <div className="field"><label htmlFor="r_state">State</label>
          <select id="r_state" name="state" defaultValue={String(state.values?.state ?? "")}><option value="">Choose a state</option>{NG_STATES.map((s) => <option key={s}>{s}</option>)}</select><Err id="r_state" error={state.errors?.state} /></div>
        {type === "CITY" && <div className="field"><label htmlFor="r_city">City</label><input id="r_city" name="city" defaultValue={String(state.values?.city ?? "")} /><Err id="r_city" error={state.errors?.city} /></div>}
        <div className="field"><label htmlFor="r_fee">Delivery fee</label><input id="r_fee" name="fee" inputMode="decimal" defaultValue={String(state.values?.fee ?? "")} /><Err id="r_fee" error={state.errors?.fee} /></div>
        <button className="btn" disabled={pending}>{pending ? "Saving…" : "Save price"}</button>
      </form>
    </section>
  );
}

"use client";
import { useActionState } from "react";
import { savePolicy } from "@/actions/policies";
import { initialState } from "@/lib/form";
import { FieldRow, FormBanner } from "./fields";

export function PolicyCard({ kind, label, policy }: { kind: string; label: string; policy: { title: string; content: string; published: boolean } }) {
  const [state, action, pending] = useActionState(savePolicy.bind(null, kind), initialState);
  const v = (k: "title" | "content" | "published") => state.values?.[k] ?? policy[k];
  return (
    <form action={action} className="card form" noValidate>
      <h2>{label}</h2>
      <FormBanner state={state} />
      <FieldRow f={{ name: "title", label: "Title", type: "text" }} value={v("title")} error={state.errors?.title} />
      <FieldRow f={{ name: "content", label: "Policy text", type: "textarea", help: "Leave a blank line between paragraphs." }} value={v("content")} error={state.errors?.content} />
      <FieldRow f={{ name: "published", label: "Show this page on the store", type: "checkbox" }} value={v("published")} />
      <button className="btn" disabled={pending}>{pending ? "Saving…" : "Save policy"}</button>
    </form>
  );
}

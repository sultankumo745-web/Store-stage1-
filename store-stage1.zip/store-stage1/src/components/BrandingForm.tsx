"use client";
import { useActionState, useState } from "react";
import { saveSection } from "@/actions/settings";
import { initialState } from "@/lib/form";
import { DEFAULT_THEME, PRESETS, THEME_KEYS, isHex, themeVars, type Theme } from "@/lib/theme";
import { ImageField, FormBanner, Err } from "./fields";

const LABELS: Record<keyof Theme, string> = { primaryColor: "Primary colour", secondaryColor: "Secondary colour", accentColor: "Accent colour", backgroundColor: "Background colour", textColor: "Text colour", buttonColor: "Button colour" };
type Img = { logoUrl: string | null; logoDarkUrl: string | null; faviconUrl: string | null };

export function BrandingForm({ theme, images, businessName }: { theme: Theme; images: Img; businessName: string }) {
  const [state, action, pending] = useActionState(saveSection.bind(null, "branding"), initialState);
  const [c, setC] = useState<Theme>({ ...theme, ...(state.values as Partial<Theme> | undefined) });
  const valid = THEME_KEYS.every((k) => isHex(c[k]));
  const pv = valid ? c : DEFAULT_THEME;
  return (
    <form action={action} className="card form" noValidate>
      <FormBanner state={state} />
      <div className="field"><span className="label">Presets (you can still change every colour)</span>
        <div className="row">{Object.entries(PRESETS).map(([n, t]) => <button type="button" key={n} className="btn ghost sm" onClick={() => setC(t)}>{n}</button>)}
          <button type="button" className="btn ghost sm" onClick={() => setC(DEFAULT_THEME)}>Reset to default</button></div></div>
      {THEME_KEYS.map((k) => (
        <div className="field" key={k}>
          <label htmlFor={`c_${k}`}>{LABELS[k]}</label>
          <div className="row">
            <input type="color" aria-label={`${LABELS[k]} picker`} value={isHex(c[k]) ? c[k] : "#000000"} onChange={(e) => setC({ ...c, [k]: e.target.value })} className="swatch" />
            <input id={`c_${k}`} name={k} value={c[k]} onChange={(e) => setC({ ...c, [k]: e.target.value })} maxLength={7} spellCheck={false} aria-invalid={!isHex(c[k])} />
          </div>
          {!isHex(c[k]) && <p className="error">Use a HEX colour like #0b6b43.</p>}
          <Err id={k} error={state.errors?.[k]} />
        </div>
      ))}
      <ImageField name="logoUrl" label="Logo" help="Used on light backgrounds. PNG, JPG or WEBP, up to 2 MB." current={images.logoUrl} error={state.errors?.logoUrl} />
      <ImageField name="logoDarkUrl" label="Logo for dark backgrounds (optional)" current={images.logoDarkUrl} error={state.errors?.logoDarkUrl} />
      <ImageField name="faviconUrl" label="Favicon" help="Small square icon for browser tabs. PNG or ICO." current={images.faviconUrl} error={state.errors?.faviconUrl} />

      <h2>Live preview</h2>
      {!valid && <p className="help">Fix the colours above to update the preview.</p>}
      <div className="preview" style={{ ...(themeVars(pv) as React.CSSProperties), background: "var(--bg)", color: "var(--text)" }}>
        <div className="pv-nav" style={{ background: "var(--secondary)", color: "var(--secondary-ink)" }}>
          {images.logoUrl ? <img src={images.logoUrl} alt="" height={24} /> : <strong>{businessName}</strong>}<span>Home</span><span>Shop</span>
        </div>
        <div className="pv-body">
          <h3 style={{ margin: 0 }}>Sample heading</h3>
          <div className="pv-card"><div className="pv-img" /><p style={{ margin: "6px 0" }}>Sample product</p><strong>₦12,500</strong> <span className="pv-badge" style={{ background: "var(--accent)", color: "var(--accent-ink)" }}>Offer</span>
            <div><span className="pv-btn" style={{ background: "var(--button)", color: "var(--button-ink)" }}>Add to cart</span></div></div>
          <a style={{ color: "var(--primary)" }} href="#" onClick={(e) => e.preventDefault()}>Sample link</a>
        </div>
      </div>
      <button className="btn" disabled={pending || !valid}>{pending ? "Saving…" : "Save branding"}</button>
    </form>
  );
}

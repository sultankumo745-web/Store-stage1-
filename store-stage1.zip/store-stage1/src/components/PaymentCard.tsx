"use client";
import { useActionState } from "react";
import { savePaymentMethod } from "@/actions/payments";
import { initialState } from "@/lib/form";
import { FieldRow, FormBanner, type Val } from "./fields";

type Row = { enabled: boolean; instructions: string | null; bankName: string | null; accountName: string | null; accountNumber: string | null; walletProvider: string | null; walletName: string | null; walletNumber: string | null };
const BANK = [["bankName", "Bank name"], ["accountName", "Account name"], ["accountNumber", "Account number (10 digits)"]] as const;
const WALLET = [["walletProvider", "Wallet provider"], ["walletName", "Wallet name"], ["walletNumber", "Wallet number"]] as const;

export function PaymentCard({ provider, label, kind, configured, envVars, row }: { provider: string; label: string; kind: "gateway" | "manual"; configured: boolean; envVars: string[]; row: Row }) {
  const [state, action, pending] = useActionState(savePaymentMethod.bind(null, provider), initialState);
  const v = (k: keyof Row): Val => state.values?.[k] ?? row[k];
  const extra = provider === "MANUAL_BANK" ? BANK : provider === "MANUAL_WALLET" ? WALLET : [];
  return (
    <form action={action} className="card form" noValidate>
      <h2>{label}</h2>
      {kind === "gateway" && <p><span className={configured ? "badge ok" : "badge warn"}>{configured ? "Configured" : "Not configured"}</span></p>}
      {kind === "gateway" && (configured
        ? <p className="help">The secret key is present on the server. It is not shown here and is not tested against {label} until the payment stage is built.</p>
        : <p className="help">To set this up, add {envVars.join(", ")} in your hosting provider&apos;s environment variables and redeploy. Secret keys are never typed into or stored by this page.</p>)}
      <FormBanner state={state} />
      <FieldRow f={{ name: "enabled", label: `Offer ${label} at checkout`, type: "checkbox" }} value={v("enabled")} error={state.errors?.enabled} />
      {extra.map(([name, text]) => <FieldRow key={name} f={{ name, label: text, type: "text" }} value={v(name)} error={state.errors?.[name]} />)}
      <FieldRow f={{ name: "instructions", label: "Instructions shown to customers", type: "textarea", help: kind === "manual" ? "Orders paid this way stay 'pending verification' until you confirm the money arrived." : undefined }} value={v("instructions")} error={state.errors?.instructions} />
      <button className="btn" disabled={pending}>{pending ? "Saving…" : "Save"}</button>
    </form>
  );
}

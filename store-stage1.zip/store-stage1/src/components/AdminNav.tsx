"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [["/admin", "Dashboard"], ["/admin/settings/business", "Business"], ["/admin/settings/branding", "Branding"], ["/admin/settings/contact", "Contact"], ["/admin/settings/social", "Social media"], ["/admin/settings/payments", "Payments"], ["/admin/settings/delivery", "Delivery"], ["/admin/settings/policies", "Policies"], ["/admin/settings/seo", "SEO"], ["/admin/settings/status", "Store status"]] as const;
export function AdminNav() {
  const path = usePathname();
  return <nav aria-label="Admin" className="nav">{LINKS.map(([href, label]) => <Link key={href} href={href} aria-current={path === href ? "page" : undefined}>{label}</Link>)}</nav>;
}

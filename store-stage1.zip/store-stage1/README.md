# Store - Stage 1 (foundation)

Next.js 15 + TypeScript + Prisma (PostgreSQL). Stage 1 delivers admin login, a central settings system, and the admin settings pages.
Products, cart, checkout, orders and live payments come in later stages.

## What is real in Stage 1
- Admin login (bcrypt, signed httpOnly cookie, per-account lockout), middleware + server-side checks on every admin page and action.
- One settings loader (`src/lib/settings.ts`), cached under tag `settings`, refreshed with `revalidateTag("settings")` after every save.
- Settings pages: business, branding (live preview, presets, reset), contact, social, payments, delivery, policies, SEO, store status.
- `StoreSettings` singleton enforced by the database (one-value enum + unique), not only by code.
- Payment methods: Paystack/Flutterwave show only "Configured / Not configured" (secrets stay in env vars); manual bank/wallet details are stored.
- Delivery pricing logic (`src/lib/delivery.ts`): city > state > default fee, free-delivery threshold. Checkout will reuse it.
- Maintenance mode and store open/closed. Storage abstraction (Vercel Blob or S3-compatible) with real file-type checks.
- Storefront shell (header, footer, home, policy pages) that reads everything from settings.

## Not in Stage 1
Products, cart, checkout, orders, payments processing, customer accounts, analytics, emails. Paystack/Flutterwave are not called yet.

## Setup
```bash
npm install
cp .env.example .env        # fill in DATABASE_URL, AUTH_SECRET (openssl rand -base64 32), NEXT_PUBLIC_SITE_URL
# first admin (used only by the seed):  ADMIN_EMAIL, ADMIN_PASSWORD (12+ chars), ADMIN_NAME
npx prisma migrate dev --name init   # creates and applies the first migration; commit prisma/migrations
npm run db:seed                      # settings row, payment methods, placeholder policies, first admin
npm run dev
```
Open http://localhost:3000/admin/login. After seeding, delete `ADMIN_PASSWORD` from your `.env`.
Production: `npm run db:deploy` (applies committed migrations), then `npm run build && npm start`, or deploy on Vercel with the same env vars.

## Environment variables
| Variable | Needed for |
|---|---|
| DATABASE_URL | Everything |
| AUTH_SECRET | Admin sessions (32+ chars) |
| NEXT_PUBLIC_SITE_URL | Metadata and share links |
| ADMIN_EMAIL, ADMIN_PASSWORD, ADMIN_NAME | First admin, seed only |
| PAYSTACK_SECRET_KEY / FLUTTERWAVE_SECRET_KEY | Shows "Configured"; used for real in the payment stage |
| STORAGE_DRIVER + BLOB_READ_WRITE_TOKEN | Logo/favicon uploads on Vercel Blob |
| STORAGE_DRIVER=s3 + S3_BUCKET, S3_REGION, S3_ACCESS_KEY_ID, S3_SECRET_ACCESS_KEY, S3_PUBLIC_BASE_URL (+ S3_ENDPOINT) | Uploads on S3/R2/Spaces |

Without storage variables, uploads show a clear setup message and nothing is pretended.

## Automated checks
`npm test` runs unit tests for phone normalisation, WhatsApp links, money maths, delivery rules, theme helpers and store status.
`npm run typecheck` runs the TypeScript compiler.

## Stage 1 test checklist (manual, after setup)
1. **Admin login**: wrong password shows an error; 5 wrong attempts lock the account 15 minutes; correct login opens /admin; signing out returns to login.
2. **Protected routes**: signed out, visit /admin and /admin/settings/payments: both redirect to /admin/login.
3. **Settings loading**: a fresh database shows "Your Store" and tagline "Quality Products, Delivered to You".
4. **Business name**: change it; header, footer, home, browser title and page metadata update.
5. **Colours**: pick a preset, save; buttons, header and links change everywhere. Button text stays readable.
6. **WhatsApp**: enter 08012345678; header and home buttons link to wa.me/2348012345678. Clear it; the buttons disappear.
7. **Social URLs**: add Facebook only; only Facebook appears in the footer. Clear it; it disappears.
8. **Currency**: change code to USD; delivery amounts display in dollars (no hard-coded symbol).
9. **Delivery rules**: set default fee, add a Lagos state price and an Ikeja city price; the table lists them; removing asks for confirmation.
10. **Policies**: edit Returns; /policies/returns shows the new text. Untick "Show": the page 404s and the footer link goes.
11. **Payments**: Paystack shows "Not configured" and cannot be enabled until `PAYSTACK_SECRET_KEY` is set. Bank transfer cannot be enabled without bank name, account name and a 10-digit number.
12. **Maintenance mode**: enable it; a private window sees the maintenance page; you (signed in) still see the store with a banner.
13. **Store closed**: untick "open"; storefront shows the closed message (checkout will honour it in Stage 2).
14. **Invalid input**: `blue` as a colour, `facebook.com/x` (no https) as a link, `12345` as a phone: each is rejected with a message and nothing is saved.
15. **Uploads**: without storage vars you see the setup message; with them, a PNG logo uploads and appears; a renamed .exe/.svg is refused.
16. **Cache invalidation**: after any save, a refresh of the storefront shows the change without a rebuild.
17. **Singleton**: `npx prisma studio` or psql: inserting a second StoreSettings row (id 2) fails on the unique `singleton` column. Running the seed twice keeps one row.

## Layout
`src/lib` pure logic and server helpers - `src/actions` server actions (all call `requireOwner`) - `src/components` forms - `src/app/(store)` public site - `src/app/admin` protected admin.

## Known limits
- Uploaded images are not resized or deleted from storage when replaced.
- Login lockout is per account (stored in the database); add a CDN/WAF rule for IP-level rate limiting in production.
- Policy placeholder text is not legal advice.

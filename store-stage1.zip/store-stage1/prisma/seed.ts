import { PrismaClient, type PolicyKind, type PaymentProvider } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();
const NOTE = "This is placeholder text. Replace it in Admin > Settings > Policies with your real policy before you start selling.";
const POLICIES: { kind: PolicyKind; title: string }[] = [
  { kind: "RETURNS", title: "Returns policy" }, { kind: "REFUNDS", title: "Refund policy" },
  { kind: "PRIVACY", title: "Privacy policy" }, { kind: "TERMS", title: "Terms and conditions" }, { kind: "DELIVERY", title: "Delivery policy" },
];
const METHODS: { provider: PaymentProvider; label: string }[] = [
  { provider: "PAYSTACK", label: "Paystack" }, { provider: "FLUTTERWAVE", label: "Flutterwave" },
  { provider: "MANUAL_BANK", label: "Bank transfer (manual)" }, { provider: "MANUAL_WALLET", label: "Wallet / mobile money (manual)" },
];

async function main() {
  await prisma.storeSettings.upsert({ where: { id: 1 }, update: {}, create: { id: 1 } }); // placeholder brand "Your Store"
  for (const [i, m] of METHODS.entries()) await prisma.paymentMethod.upsert({ where: { provider: m.provider }, update: {}, create: { ...m, sortOrder: i + 1, enabled: false } });
  for (const p of POLICIES) await prisma.policy.upsert({ where: { kind: p.kind }, update: {}, create: { ...p, content: NOTE, published: true } });
  // Delivery starts disabled with no rules: no invented fees. The owner configures it in admin.

  if ((await prisma.adminUser.count()) === 0) {
    const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
    const password = process.env.ADMIN_PASSWORD;
    if (!email || !password) return console.log("No admin yet. Set ADMIN_EMAIL and ADMIN_PASSWORD (12+ characters) and run the seed again.");
    if (password.length < 12) throw new Error("ADMIN_PASSWORD must be at least 12 characters.");
    await prisma.adminUser.create({ data: { email, name: process.env.ADMIN_NAME || "Store Owner", passwordHash: await bcrypt.hash(password, 12), role: "OWNER" } });
    console.log(`Created owner account for ${email}. Remove ADMIN_PASSWORD from your environment now.`);
  }
}
main().finally(() => prisma.$disconnect());
